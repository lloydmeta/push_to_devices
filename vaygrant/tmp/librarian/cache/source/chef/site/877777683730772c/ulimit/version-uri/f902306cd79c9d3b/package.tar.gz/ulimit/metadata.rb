maintainer       "Brian Hatfield"
maintainer_email "bmhatfield@gmail.com"
license          "Apache 2.0"
description      "Installs/Configures ulimit"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
name             "ulimit"
version          "0.3.2"
