# CHANGELOG for mongodb-10gen

This file is used to list changes made in each version of mongodb-10gen.

## 0.1.6:

*  Issue #1 replSet is blank in the mongo.conf file.

## 0.1.5:

* support debian.

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
